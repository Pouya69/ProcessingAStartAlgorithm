public class Pixel {
    float x;
    float y;

    public Pixel(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
