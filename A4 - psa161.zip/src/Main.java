import processing.core.PApplet;

public class Main {
    public static void main(String[] args) {
        PApplet.main(ProcessingMain.class.getName());
    }
}
